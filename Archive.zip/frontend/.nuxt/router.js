import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _9e895dc6 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _1f396120 = () => interopDefault(import('../pages/profile/index.vue' /* webpackChunkName: "pages/profile/index" */))
const _7173bf48 = () => interopDefault(import('../pages/rate.vue' /* webpackChunkName: "pages/rate" */))
const _3d359c96 = () => interopDefault(import('../pages/recommendation.vue' /* webpackChunkName: "pages/recommendation" */))
const _3495569f = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _b1be27b8 = () => interopDefault(import('../pages/search.vue' /* webpackChunkName: "pages/search" */))
const _c3b305f0 = () => interopDefault(import('../pages/admin/dashboard.vue' /* webpackChunkName: "pages/admin/dashboard" */))
const _31d8a3f4 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/login",
    component: _9e895dc6,
    name: "login"
  }, {
    path: "/profile",
    component: _1f396120,
    name: "profile"
  }, {
    path: "/rate",
    component: _7173bf48,
    name: "rate"
  }, {
    path: "/recommendation",
    component: _3d359c96,
    name: "recommendation"
  }, {
    path: "/register",
    component: _3495569f,
    name: "register"
  }, {
    path: "/search",
    component: _b1be27b8,
    name: "search"
  }, {
    path: "/admin/dashboard",
    component: _c3b305f0,
    name: "admin-dashboard"
  }, {
    path: "/",
    component: _31d8a3f4,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}

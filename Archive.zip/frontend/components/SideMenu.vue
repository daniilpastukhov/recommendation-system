<template>
  <v-container>

  </v-container>
</template>

<script>
    export default {
        components: {},
        data() {
            return {
                // data

            }
        },
        methods: {
            // methods
        }
    }
</script>

<style scoped>

</style>

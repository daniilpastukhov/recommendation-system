<template>
  <p>admin dashboard</p>
</template>

<script>
export default {

}
</script>

<style>

</style>